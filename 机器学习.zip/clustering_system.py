import numpy as np
import warnings
from clustering_algorithm import clustering_performance_index
from clustering_plot import plot_clustering, draw_histogram

if __name__ == "__main__":
    """
    page-blocks.csv titanic.csv heart.csv
    clustering_list = ["k_means", "BIRCH", "DBSCAN", "GMM", "OPTICS", "CLIQUE", "MeanShift"]
    indicator_scores = ["adjusted_rand_score", "adjusted_mutual_info_score", "homogeneity_score",
                        "silhouette_score", "calinski_harabasz_score", "davies_bouldin_score"]
    """
    warnings.filterwarnings("ignore")
    # plot_clustering("heart.csv", "BIRCH")
    draw_histogram("heart.csv", "adjusted_rand_score")  # # 有关指标的计算没有"CLIQUE"算法

