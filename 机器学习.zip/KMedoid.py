import numpy as np
import random


def ou_distance(x, y):
    """
    距离公式
    :param x: 数据点的横坐标
    :param y: 数据点的纵坐标
    :return: 距离
    """
    return np.sqrt(sum(np.square(x - y)))


def KMed(data, k_num_center):
    """
    选定好距离公式开始进行训练
    :param k_num_center: 聚类中心点的个数
    :param data: 聚类数据
    :param ou_distance: 距离度量公式函数
    :return: 聚类生成的样本簇
    """
    print('初始化', k_num_center, '个中心点')
    indexs = list(range(len(data)))
    random.shuffle(indexs)  # 随机选择质心
    init_centroids_index = indexs[:k_num_center]
    centroids = data[init_centroids_index, :]  # 初始中心点
    # 确定种类编号
    levels = list(range(k_num_center))
    print('开始迭代')
    sample_target = []
    if_stop = False
    while (not if_stop):
        if_stop = True
        classify_points = [[centroid] for centroid in centroids]
        sample_target = []
        # 遍历数据
        for sample in data:
            # 计算距离，由距离该数据最近的核心，确定该点所属类别
            distances = [ou_distance(sample, centroid) for centroid in centroids]
            cur_level = np.argmin(distances)
            sample_target.append(cur_level)
            # 统计，方便迭代完成后重新计算中间点
            classify_points[cur_level].append(sample)
        # 重新划分质心
        for i in range(k_num_center):  # 几类中分别寻找一个最优点
            distances = [ou_distance(point_1, centroids[i]) for point_1 in classify_points[i]]
            now_distances = sum(distances)  # 首先计算出现在中心点和其他所有点的距离总和
            for point in classify_points[i]:
                distances = [ou_distance(point_1, point) for point_1 in classify_points[i]]
                new_distance = sum(distances)
                # 计算出该聚簇中各个点与其他所有点的总和，若是有小于当前中心点的距离总和的，中心点去掉
                if new_distance < now_distances:
                    now_distances = new_distance
                    centroids[i] = point  # 换成该点
                    if_stop = False
    print('结束')
    return np.array(sample_target)

