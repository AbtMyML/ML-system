import numpy as np
import warnings

from regression_plot import plot_regression_curve, plot_index_polyline

if __name__ == "__main__":
    """
    ["byes", "Markov", "Linear", "Ridge", "XGB", "polynomial", "cart"]
    ["neg_mean_absolute_error", "neg_mean_squared_error", "neg_median_absolute_error", "r2"]
    """
    warnings.filterwarnings("ignore")
    plot_regression_curve("dee.csv", "polynomial")
    # plot_index_polyline("dee.csv", "neg_mean_absolute_error")  # 没有马尔可夫模型

