import numpy as np
from matplotlib import pyplot as plt
from sklearn.cluster import KMeans, AgglomerativeClustering, DBSCAN
from sklearn.datasets import load_iris
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.preprocessing import StandardScaler

from KMedoid import KMed


def cluster_processing(data):
    """
    :return: 返回标准化和PCA降维之后的数据
    """
    # 数据标准化
    sc = StandardScaler()  # 初始化一个对象sc去对数据集作变换
    sc.fit(data)  # 用对象去拟合数据集X_train，并且存下来拟合参数
    X = sc.transform(data)
    pca = PCA(n_components=2)  # 实例化
    pca = pca.fit(X)  # 拟合模型
    X = pca.transform(X)  # 获取新矩阵

    return X


def plot_clustering(X, labels, clustering_name):
    """
    :param labels: 聚类生成的簇
    :param X: 原始数据
    :param clustering_name: 聚类模型名称
    :return: 聚类散点图
    """
    colors = ["olive", "pink", "cyan", "darkred", "forestgreen", "beige", "burlywood",
              "hotpink", "lightskyblue", "mediumpurple"]
    n_clusters_ = len(np.unique(labels))
    plt.figure(figsize=(12, 10))
    for k, col in zip(range(n_clusters_), colors[:n_clusters_]):
        my_members = labels == k  # 知识点 将判断的布尔值返回给一个变量 会少一个条件语句
        # X[my_members, 0]属于是numpy数组布尔型索引
        # 之后在筛选numpy数组的时候可以考虑使用此方法(布尔值索引) 减少了循环和判断语句 代码效率更高
        # 在写代码的时候多思考代码效率 尽量少循环多函数 少套娃多函数 功能模块化 让代码效率提起来
        plt.plot(X[my_members, 0], X[my_members, 1], "o", markerfacecolor=col,
                 markeredgecolor="k", markersize=6)
    plt.xlabel("Attribute 1")
    plt.ylabel("Attribute 2")
    plt.title(clustering_name)
    plt.savefig("E:/桌面/数据挖掘/实验4/"+clustering_name+".svg")
    plt.show()


def clustering_performance_index(X, labels_true, labels_pred):
    """
    :param labels_pred: 聚类之后的簇
    :param labels_true: 原始数决策属性标签
    :param X: 原始数据
    :return: 聚类的各个指标的数值
    """
    all_scores = []
    for labelpre in labels_pred:
        indicator_scores = [adjusted_rand_score(labels_true, labelpre),
                            silhouette_score(X, labelpre)]
        all_scores.append([round(score, 4) for score in indicator_scores])

    return np.array(all_scores)


def draw_histogram(clustering_list, score_data, score):
    """
    :param score_data: 各个算法指标的值
    :param clustering_list: 横坐标各个算法名称
    :param score: 绘制柱状图指标名称["adjusted_rand_score", "silhouette_score"]
    :return: 指定指标柱状图
    """
    fig = plt.figure(figsize=(12, 10))  # 设置画布大小，防止x轴标签拥挤
    plt.bar(clustering_list, score_data, width=0.6)
    x = np.arange(len(score_data))
    for a, b in zip(x, score_data):  # 标记值
        plt.text(a, b, '%.4f' % b, ha='center', va='bottom', fontsize=14, fontdict={'family': 'Times New Roman'})
    plt.xlabel('Algorithm', fontdict={'family': 'Times New Roman', 'size': 15})
    plt.ylabel('Recall Standard Deviation', fontdict={'family': 'Times New Roman', 'size': 15})
    plt.yticks(FontProperties='Times New Roman', size=14)
    plt.xticks(FontProperties='Times New Roman', size=14)
    plt.title(score, fontdict={'family': 'Times New Roman', 'size': 20})
    plt.savefig("E:/桌面/数据挖掘/实验4/"+score+".svg")
    plt.show()


if __name__ == "__main__":
    iris_data = load_iris().data
    iris_target = load_iris().target
    # K-means
    km = KMeans(n_clusters=3).fit(iris_data)
    km_labels = km.predict(iris_data)
    # K-medoid
    KMe_labels = KMed(iris_data, 3)
    # 层次聚类
    agg = AgglomerativeClustering().fit(iris_data)
    agg_labels = agg.labels_
    # DBSCAN密度聚类
    dbscan = DBSCAN(eps=0.8, min_samples=30).fit(iris_data)
    dascan_labels = dbscan.labels_

    X = cluster_processing(iris_data)
    plot_clustering(X, dascan_labels, "DBSCAN")

    labels_pred = [km_labels, KMe_labels, agg_labels, dascan_labels]
    score_data = clustering_performance_index(X, iris_target, labels_pred)[:, 1]
    draw_histogram(["K_means", "K_medoid", "AGG", "DBSCAN"], score_data, "silhouette_score")
