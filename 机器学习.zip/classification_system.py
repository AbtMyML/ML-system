import numpy as np
import warnings
from classify_plot import scatter, plot_roc, plot_radar


if __name__ == "__main__":
    """
    page-blocks.csv pima.csv heart.csv
    classify_list = ["KNN", "byes", "GBDT", "cart", "BP", "AdaBoost", "RF", "Logistic"]
    scores = ["accuracy", "precision_weighted", "recall_weighted", "f1_weighted"]
    """
    warnings.filterwarnings("ignore")
    plot_roc("heart.csv", "BP")  # 注意不可绘制page-blocks.csv (多分类不可)
    # scatter("heart.csv", "KNN")
    # plot_radar("heart.csv", "recall_weighted")
