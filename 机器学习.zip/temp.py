from collections import Counter

import numpy as np
from matplotlib import pyplot as plt
from sklearn.datasets import load_iris
from sklearn.metrics import auc
from sklearn.model_selection import KFold
from sklearn.neighbors import KNeighborsClassifier
import sklearn.model_selection as ms
from sklearn.tree import DecisionTreeClassifier

data = load_iris().data
data_target = load_iris().target

clf = DecisionTreeClassifier(criterion='entropy')

scores = ["accuracy", "precision_weighted", "recall_weighted", "f1_weighted"]
all_scores = np.ones((1, len(scores)))
for j in range(len(scores)):
    all_scores[0, j] = ms.cross_val_score(clf, data, data_target, cv=5, scoring=scores[j]).mean()

# 画图
indicator_scores = ["adjusted_rand_score", "adjusted_mutual_info_score", "homogeneity_score",
                        "silhouette_score", "calinski_harabasz_score", "davies_bouldin_score"]
score_data = all_scores[0]
fig = plt.figure(figsize=(12, 10))  # 设置画布大小，防止x轴标签拥挤
plt.bar(scores, score_data, width=0.6)
x = np.arange(len(score_data))
for a, b in zip(x, score_data):  # 标记值
    plt.text(a, b, '%.4f' % b, ha='center', va='bottom', fontsize=14, fontdict={'family': 'Times New Roman'})
plt.xlabel("C4.5", fontdict={'family': 'Times New Roman', 'size': 15})
plt.ylabel("Index Value", fontdict={'family': 'Times New Roman', 'size': 15})
plt.yticks(FontProperties='Times New Roman', size=14)
plt.xticks(FontProperties='Times New Roman', size=14)
plt.show()

